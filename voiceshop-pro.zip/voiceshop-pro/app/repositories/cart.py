from copy import deepcopy
from threading import Lock

from app.domain.models import Cart, CartLine


class CartRepository:
    def __init__(self) -> None:
        self._carts: dict[str, Cart] = {}
        self._lock = Lock()

    def get(self, session_id: str) -> Cart:
        with self._lock:
            cart = self._carts.setdefault(session_id, Cart(session_id=session_id))
            return deepcopy(cart)

    def add(self, session_id: str, line: CartLine) -> Cart:
        with self._lock:
            cart = self._carts.setdefault(session_id, Cart(session_id=session_id))
            current = next(
                (item for item in cart.items if item.product_id == line.product_id), None
            )
            if current:
                current.quantity += line.quantity
                current.subtotal_clp = current.quantity * current.unit_price_clp
            else:
                cart.items.append(line)
            cart.total_clp = sum(item.subtotal_clp for item in cart.items)
            return deepcopy(cart)

    def clear(self, session_id: str) -> Cart:
        with self._lock:
            cart = Cart(session_id=session_id)
            self._carts[session_id] = cart
            return deepcopy(cart)
