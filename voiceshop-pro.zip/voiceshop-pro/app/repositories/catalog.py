import json
from pathlib import Path

from app.domain.models import Product


class CatalogRepository:
    def __init__(self, data_file: Path | None = None) -> None:
        self._data_file = (
            data_file or Path(__file__).resolve().parents[1] / "data" / "products.json"
        )
        self._products = self._load()

    def _load(self) -> list[Product]:
        raw = json.loads(self._data_file.read_text(encoding="utf-8"))
        return [Product.model_validate(item) for item in raw]

    def list_all(self) -> list[Product]:
        return list(self._products)

    def get(self, product_id: str) -> Product | None:
        return next((p for p in self._products if p.id == product_id), None)

    def search(self, query: str, presentation: str | None = None) -> list[Product]:
        q = self._normalize(query)
        presentation_q = self._normalize(presentation or "")
        matches: list[Product] = []
        for product in self._products:
            haystack = " ".join([product.name, product.presentation, *product.aliases])
            normalized = self._normalize(haystack)
            if q and q not in normalized:
                continue
            if presentation_q and presentation_q not in normalized:
                continue
            matches.append(product)
        return matches

    @staticmethod
    def _normalize(value: str) -> str:
        table = str.maketrans("áéíóúüñ", "aeiouun")
        return " ".join(value.lower().translate(table).replace("°", "").split())
