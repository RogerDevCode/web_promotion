from fastapi import APIRouter, Depends, HTTPException, Request

from app.core.config import Settings, get_settings
from app.domain.models import Cart, ChatRequest, ChatResponse, Product
from app.repositories.cart import CartRepository
from app.repositories.catalog import CatalogRepository
from app.services.nlp import DeterministicNlpService
from app.services.openai_adapter import OpenAIIntentAdapter
from app.services.shop import ShopService

router = APIRouter(prefix="/api/v1")


def catalog(request: Request) -> CatalogRepository:
    return request.app.state.catalog


def carts(request: Request) -> CartRepository:
    return request.app.state.carts


@router.get("/health")
def health(settings: Settings = Depends(get_settings)) -> dict[str, str | bool]:
    return {"status": "ok", "environment": settings.app_env, "openai_enabled": settings.use_openai}


@router.get("/products", response_model=list[Product])
def products(repo: CatalogRepository = Depends(catalog)) -> list[Product]:
    return repo.list_all()


@router.get("/cart/{session_id}", response_model=Cart)
def get_cart(session_id: str, repo: CartRepository = Depends(carts)) -> Cart:
    return repo.get(session_id)


@router.delete("/cart/{session_id}", response_model=Cart)
def clear_cart(session_id: str, repo: CartRepository = Depends(carts)) -> Cart:
    return repo.clear(session_id)


@router.post("/chat", response_model=ChatResponse)
async def chat(
    payload: ChatRequest,
    request: Request,
    settings: Settings = Depends(get_settings),
) -> ChatResponse:
    catalog_repo: CatalogRepository = request.app.state.catalog
    cart_repo: CartRepository = request.app.state.carts
    mode = "deterministic"
    try:
        if settings.use_openai:
            if not settings.openai_api_key:
                raise HTTPException(status_code=503, detail="OPENAI_API_KEY no configurada")
            intent = await OpenAIIntentAdapter(settings).parse(payload.message)
            mode = "openai"
        else:
            intent = DeterministicNlpService(catalog_repo).parse(payload.message)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Error del proveedor de IA: {exc}") from exc

    return ShopService(catalog_repo, cart_repo).handle(payload.session_id, intent, mode)
