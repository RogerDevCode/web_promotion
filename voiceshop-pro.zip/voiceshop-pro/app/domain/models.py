from typing import Literal

from pydantic import BaseModel, Field, field_validator


class Product(BaseModel):
    id: str
    name: str
    category: str
    presentation: str
    unit: str
    price_clp: int = Field(ge=0)
    stock: int = Field(ge=0)
    aliases: list[str] = Field(default_factory=list)


class CartLine(BaseModel):
    product_id: str
    name: str
    presentation: str
    quantity: int = Field(gt=0)
    unit_price_clp: int = Field(ge=0)
    subtotal_clp: int = Field(ge=0)


class Cart(BaseModel):
    session_id: str
    items: list[CartLine] = Field(default_factory=list)
    total_clp: int = Field(default=0, ge=0)


class Intent(BaseModel):
    action: Literal["search", "add", "remove", "show_cart", "checkout", "unknown"]
    product_name: str | None = None
    presentation: str | None = None
    quantity: int | None = Field(default=None, gt=0)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    raw_text: str

    @field_validator("product_name", "presentation")
    @classmethod
    def clean_optional_text(cls, value: str | None) -> str | None:
        return value.strip() if value else value


class ChatRequest(BaseModel):
    session_id: str = Field(min_length=3, max_length=100)
    message: str = Field(min_length=1, max_length=500)


class ChatResponse(BaseModel):
    reply: str
    intent: Intent
    cart: Cart
    products: list[Product] = Field(default_factory=list)
    mode: Literal["deterministic", "openai"]
