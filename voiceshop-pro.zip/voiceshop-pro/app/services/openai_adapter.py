import json

from openai import AsyncOpenAI

from app.core.config import Settings
from app.domain.models import Intent


class OpenAIIntentAdapter:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = AsyncOpenAI(api_key=settings.openai_api_key)

    async def parse(self, text: str) -> Intent:
        schema = Intent.model_json_schema()
        response = await self.client.responses.create(
            model=self.settings.openai_model,
            input=[
                {
                    "role": "system",
                    "content": (
                        "Extrae una intención de venta retail. No inventes productos. "
                        "Acciones válidas: search, add, remove, show_cart, checkout, unknown."
                    ),
                },
                {"role": "user", "content": text},
            ],
            text={
                "format": {
                    "type": "json_schema",
                    "name": "retail_intent",
                    "schema": schema,
                    "strict": True,
                }
            },
        )
        payload = json.loads(response.output_text)
        return Intent.model_validate(payload)
