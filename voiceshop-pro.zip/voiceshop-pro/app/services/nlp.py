import re

from app.domain.models import Intent, Product
from app.repositories.catalog import CatalogRepository

NUMBER_WORDS = {
    "un": 1,
    "una": 1,
    "uno": 1,
    "dos": 2,
    "tres": 3,
    "cuatro": 4,
    "cinco": 5,
    "seis": 6,
    "siete": 7,
    "ocho": 8,
    "nueve": 9,
    "diez": 10,
}


class DeterministicNlpService:
    def __init__(self, catalog: CatalogRepository) -> None:
        self.catalog = catalog

    def parse(self, text: str) -> Intent:
        normalized = CatalogRepository._normalize(text)
        action = self._action(normalized)
        quantity = self._quantity(normalized)
        products = self._detect_products(normalized)
        selected = products[0] if products else None
        presentation = self._presentation(normalized, selected)
        confidence = (
            0.92
            if selected and action in {"search", "add"}
            else 0.75
            if action != "unknown"
            else 0.25
        )
        return Intent(
            action=action,
            product_name=selected.name if selected else None,
            presentation=presentation,
            quantity=quantity,
            confidence=confidence,
            raw_text=text,
        )

    def _action(self, text: str) -> str:
        if any(word in text for word in ("carrito", "pedido actual", "que llevo")):
            return "show_cart"
        if any(word in text for word in ("finalizar", "confirmar pedido", "comprar", "checkout")):
            return "checkout"
        if any(
            word in text for word in ("agrega", "agregar", "quiero", "dame", "necesito", "llevo")
        ):
            return "add"
        if any(word in text for word in ("tienes", "hay", "buscar", "precio", "cuanto cuesta")):
            return "search"
        return "unknown"

    def _quantity(self, text: str) -> int | None:
        for word, value in NUMBER_WORDS.items():
            if re.search(rf"\b{word}\b", text):
                return value
        digit = re.search(r"\b(\d{1,3})\b(?!\s*(?:cc|ml|litro|litros|l)\b)", text)
        if digit:
            return int(digit.group(1))
        return None

    def _detect_products(self, text: str) -> list[Product]:
        scored: list[tuple[int, Product]] = []
        for product in self.catalog.list_all():
            candidates = [product.name, *product.aliases]
            score = max(
                (
                    len(CatalogRepository._normalize(c))
                    for c in candidates
                    if CatalogRepository._normalize(c) in text
                ),
                default=0,
            )
            if score:
                scored.append((score, product))
        return [product for _, product in sorted(scored, key=lambda item: item[0], reverse=True)]

    def _presentation(self, text: str, product: Product | None) -> str | None:
        patterns = [r"(\d{3,4})\s*(?:cc|ml)", r"(\d)\s*(?:litro|litros|l)"]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                unit = "cc" if "cc" in text or "ml" in text else "litros"
                return f"{match.group(1)} {unit}"
        return product.presentation if product else None
