from app.domain.models import CartLine, ChatResponse, Intent, Product
from app.repositories.cart import CartRepository
from app.repositories.catalog import CatalogRepository


class ShopService:
    def __init__(self, catalog: CatalogRepository, carts: CartRepository) -> None:
        self.catalog = catalog
        self.carts = carts

    def handle(self, session_id: str, intent: Intent, mode: str) -> ChatResponse:
        cart = self.carts.get(session_id)
        products: list[Product] = []

        if intent.action == "show_cart":
            reply = self._cart_reply(cart)
        elif intent.action == "checkout":
            reply = "El pedido quedó preparado para revisión humana. En producción se enviaría al vendedor."
        elif intent.action in {"search", "add"} and intent.product_name:
            products = self.catalog.search(intent.product_name, intent.presentation)
            if not products:
                products = self.catalog.search(intent.product_name)
            if not products:
                reply = f"No encontré {intent.product_name} en el catálogo de demostración."
            elif intent.action == "search":
                reply = self._product_reply(products)
            else:
                product = products[0]
                quantity = intent.quantity or 1
                if quantity > product.stock:
                    reply = f"Solo quedan {product.stock} unidades de {product.name}."
                else:
                    line = CartLine(
                        product_id=product.id,
                        name=product.name,
                        presentation=product.presentation,
                        quantity=quantity,
                        unit_price_clp=product.price_clp,
                        subtotal_clp=product.price_clp * quantity,
                    )
                    cart = self.carts.add(session_id, line)
                    reply = (
                        f"Agregué {quantity} {product.unit}{'s' if quantity != 1 else ''} de "
                        f"{product.name}, {product.presentation}. Total del carrito: "
                        f"${cart.total_clp:,.0f} pesos. ¿Deseas algo más?"
                    ).replace(",", ".")
        else:
            reply = (
                "Puedo buscar productos, informar precio y stock, agregarlos al carrito o mostrar el pedido. "
                "Prueba diciendo: agrega dos cajas de Cerveza Cristal de 500 cc."
            )

        return ChatResponse(reply=reply, intent=intent, cart=cart, products=products, mode=mode)  # type: ignore[arg-type]

    @staticmethod
    def _product_reply(products: list[Product]) -> str:
        product = products[0]
        return (
            f"Sí, hay {product.stock} disponibles de {product.name}, {product.presentation}, "
            f"a ${product.price_clp:,.0f} pesos por {product.unit}."
        ).replace(",", ".")

    @staticmethod
    def _cart_reply(cart: object) -> str:
        from app.domain.models import Cart

        assert isinstance(cart, Cart)
        if not cart.items:
            return "El carrito está vacío."
        detail = ", ".join(f"{i.quantity} de {i.name}" for i in cart.items)
        return f"Llevas {detail}. Total: ${cart.total_clp:,.0f} pesos.".replace(",", ".")
