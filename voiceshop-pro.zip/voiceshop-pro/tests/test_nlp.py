from app.repositories.catalog import CatalogRepository
from app.services.nlp import DeterministicNlpService


def test_extracts_spanish_number_word():
    intent = DeterministicNlpService(CatalogRepository()).parse(
        "Necesito diez cajas de cerveza Cristal de 500 cc"
    )
    assert intent.action == "add"
    assert intent.quantity == 10
    assert intent.product_name == "Cerveza Cristal"


def test_show_cart_intent():
    intent = DeterministicNlpService(CatalogRepository()).parse("¿Qué llevo en el carrito?")
    assert intent.action == "show_cart"
