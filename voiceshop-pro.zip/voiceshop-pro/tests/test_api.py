def test_health(client):
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_catalog_has_products(client):
    response = client.get("/api/v1/products")
    assert response.status_code == 200
    assert len(response.json()) >= 5


def test_add_cristal_to_cart(client):
    response = client.post(
        "/api/v1/chat",
        json={"session_id": "qa-session", "message": "Agrega 2 cajas de cerveza Cristal de 500 cc"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["intent"]["action"] == "add"
    assert data["intent"]["quantity"] == 2
    assert data["cart"]["items"][0]["name"] == "Cerveza Cristal"
    assert data["cart"]["total_clp"] == 49980


def test_stock_guard(client):
    response = client.post(
        "/api/v1/chat",
        json={"session_id": "stock-session", "message": "Quiero 99 cajas de Cristal 500"},
    )
    assert response.status_code == 200
    assert "Solo quedan" in response.json()["reply"]
    assert response.json()["cart"]["items"] == []


def test_unknown_intent_is_safe(client):
    response = client.post(
        "/api/v1/chat", json={"session_id": "unknown-session", "message": "Cuéntame un poema"}
    )
    assert response.status_code == 200
    assert response.json()["intent"]["action"] == "unknown"
