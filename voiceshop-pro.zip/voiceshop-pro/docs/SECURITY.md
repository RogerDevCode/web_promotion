# Seguridad

## Controles incluidos

- Pydantic limita longitud, tipos y cantidades.
- El navegador no envía precios ni subtotales confiables.
- El backend recalcula todo.
- La API key se lee desde `.env` y no se entrega al frontend.
- CORS configurable.
- Una intención desconocida no ejecuta operaciones.

## Obligatorio antes de producción

- Autenticación o sesión firmada.
- PostgreSQL con transacciones.
- Redis para rate limiting, idempotencia y locks de stock.
- Confirmación explícita antes de crear pedido.
- Auditoría de conversaciones y acciones, con política de privacidad.
- Moderación y restricciones de edad donde aplique, especialmente para alcohol.
- No almacenar audio sin consentimiento informado.
- HTTPS obligatorio.
- Secret manager, rotación de claves y separación por empresa/tenant.
- Validación legal local para venta de alcohol, horarios, despacho y verificación de mayoría de edad.
