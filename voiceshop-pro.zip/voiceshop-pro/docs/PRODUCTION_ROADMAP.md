# Roadmap hacia producción

## Fase 1 — Demo comercial

Este repositorio: catálogo JSON, carrito en memoria, voz del navegador, UI visible.

## Fase 2 — Piloto de un cliente

- PostgreSQL.
- Redis.
- Catálogo importado desde CSV/ERP.
- Login administrativo.
- Pedido enviado a humano por Telegram, WhatsApp o panel web.
- Métricas de conversión y abandono.

## Fase 3 — Voz Realtime

- WebRTC en navegador para baja latencia.
- Backend que genera credenciales efímeras.
- Tools: buscar producto, consultar stock, agregar, quitar y preparar checkout.
- Interrupción de voz y detección de turno.

## Fase 4 — SaaS multiempresa

- `tenant_id` en cada entidad.
- Configuración de voz, marca, catálogo, horarios y reglas por comercio.
- Facturación, límites de uso y observabilidad.
- Backups, SLA y soporte.
