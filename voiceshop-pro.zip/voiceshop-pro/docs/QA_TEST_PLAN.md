# Plan de QA

## Pirámide de pruebas

1. Unitarias: parser, búsqueda, totalización y repositorios.
2. Integración: endpoints con `TestClient`.
3. Contrato: formas JSON validadas por Pydantic/OpenAPI.
4. UI manual: micrófono, teclado, carrito, voz y diseño responsive.
5. Seguridad: secretos, validación, CORS, límites y abuso.

## Matriz funcional mínima

| ID | Entrada | Resultado esperado |
|---|---|---|
| F01 | `Agrega 2 cajas de Cristal 500` | 2 cajas; total 49.980 |
| F02 | `¿Tienes pisco Mistral?` | precio y stock; carrito sin cambios |
| F03 | `Quiero 99 cajas de Cristal` | rechazo por stock |
| F04 | `¿Qué llevo en el carrito?` | detalle y total |
| F05 | `Cuéntame un poema` | intención unknown; sin efectos |
| F06 | dos session_id distintos | carritos aislados |
| F07 | mensaje vacío o >500 caracteres | HTTP 422 |

## QA automatizado

```bash
make qa
```

Debe ejecutar:

- Ruff.
- Pytest con cobertura.
- Compilación de módulos Python.

## QA manual de navegador

- Chrome/Edge: permiso de micrófono, transcripción y respuesta hablada.
- Firefox: confirmar fallback escrito si SpeechRecognition no está disponible.
- 360 px, 768 px y 1440 px: no debe existir scroll horizontal.
- Tecla Enter envía el mensaje.
- Vaciar carrito reinicia total.
- Un error HTTP aparece en la tarjeta del asistente.

## Pruebas recomendadas antes de producción

- Carga con Locust o k6.
- Pruebas E2E con Playwright.
- Chaos testing del proveedor de IA.
- Evaluaciones de intención con 200 frases chilenas reales.
- Red-team: prompt injection, productos inexistentes, precios manipulados, cantidades negativas y replay de solicitudes.
