# Arquitectura

## Diagrama de bloques

```text
Navegador
  ├─ Micrófono → Web Speech Recognition (modo demo)
  ├─ Texto → POST /api/v1/chat
  ├─ Panel de intención
  ├─ Carrito
  └─ Speech Synthesis ← respuesta textual
                    │
                    ▼
                 FastAPI
  ├─ API routes
  ├─ NLP determinista u OpenAI structured output
  ├─ ShopService: reglas de negocio
  ├─ CatalogRepository: products.json
  └─ CartRepository: memoria por session_id
```

## Regla principal

La LLM nunca modifica stock ni carrito directamente. Solo propone una intención estructurada. `ShopService` valida la intención y ejecuta reglas deterministas.

## Fronteras

- `domain`: contratos Pydantic.
- `repositories`: acceso a datos.
- `services`: interpretación y negocio.
- `api`: transporte HTTP.
- `static`: interfaz web.

## Evolución recomendada

1. PostgreSQL para catálogo, precios, stock y pedidos.
2. Redis para sesiones, idempotencia, rate limiting y locks.
3. OpenAI Realtime API vía WebRTC para conversación full-duplex en navegador.
4. Tokens efímeros generados en backend; jamás entregar la API key al navegador.
5. Worker de pedidos y panel humano.
6. Auditoría de cada tool call y confirmación explícita antes de checkout.
