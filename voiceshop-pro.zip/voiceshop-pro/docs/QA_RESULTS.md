# Resultado de QA de esta entrega

Fecha de validación: 2026-07-10.

## Resultado

- Ruff: aprobado, 0 errores.
- Pytest: 7 pruebas aprobadas.
- Cobertura total del backend: 86 %.
- `compileall`: aprobado.
- Caso comercial principal: 2 cajas de Cerveza Cristal de 500 cc = CLP 49.980.
- Control de stock excesivo: aprobado.
- Intención desconocida sin efectos laterales: aprobado.

## Defecto encontrado y corregido

La primera implementación podía interpretar `500 cc` como cantidad 500. Se corrigió el parser para excluir números seguidos por unidades de volumen y priorizar números escritos en palabras.

## Riesgos no cubiertos en esta demo

- Reconocimiento de voz depende del navegador.
- Adaptador OpenAI requiere una clave válida y consumo de API.
- No se hicieron pruebas de carga ni E2E con navegador real.
- El carrito en memoria se pierde al reiniciar el servidor.
