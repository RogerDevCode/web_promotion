# API

Base: `/api/v1`

## GET /health

Devuelve estado del servicio y si OpenAI está habilitado.

## GET /products

Lista el catálogo.

## POST /chat

Entrada:

```json
{"session_id":"uuid-o-id-seguro","message":"Agrega dos cajas de Cristal de 500 cc"}
```

Salida resumida:

```json
{
  "reply":"Agregué 2 cajas...",
  "intent":{"action":"add","product_name":"Cerveza Cristal","quantity":2},
  "cart":{"items":[],"total_clp":49980},
  "products":[],
  "mode":"deterministic"
}
```

## GET /cart/{session_id}

Obtiene el carrito de la sesión.

## DELETE /cart/{session_id}

Vacía el carrito.
