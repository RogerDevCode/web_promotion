# Guía para replicar el proyecto con una LLM

## Objetivo inmutable

Construir una demo web de ventas por voz para retail. Debe funcionar sin servicios externos y permitir activar OpenAI opcionalmente. El backend es la autoridad para catálogo, stock, precio y carrito.

## Stack obligatorio

- Python 3.12 o superior.
- FastAPI y Pydantic v2.
- HTML, CSS y JavaScript sin framework.
- Pytest y Ruff.
- Catálogo JSON en la demo.
- API key solo en backend.

## Árbol exigido

```text
app/api
app/core
app/domain
app/repositories
app/services
app/static
app/data
tests
docs
scripts
```

## Contratos mínimos

`Product`: id, name, category, presentation, unit, price_clp, stock, aliases.

`Intent`: action, product_name, presentation, quantity, confidence, raw_text.

`ChatResponse`: reply, intent, cart, products, mode.

## Reglas funcionales

1. Interpretar `Agrega 10 cajas de Cerveza Cristal de 500 cc`.
2. No agregar más cantidad que el stock disponible.
3. Calcular subtotales y total exclusivamente en backend.
4. Mantener carritos separados por `session_id`.
5. Ante una intención desconocida, explicar capacidades sin ejecutar acciones.
6. Nunca aceptar precio o subtotal enviado por el cliente.
7. Antes de producción, checkout requiere confirmación y revisión humana.

## Prompt maestro para otra LLM

Copia este bloque en la LLM responsable de replicarlo:

```text
Actúa como arquitecto Python senior, desarrollador frontend y QA lead.
Genera un proyecto completo llamado VoiceShop Pro con FastAPI, Pydantic v2,
HTML/CSS/JavaScript sin framework, catálogo JSON, carrito por sesión y pruebas Pytest.

La aplicación debe demostrar una venta por voz. En modo gratuito utilizará Web Speech API
del navegador para reconocimiento y síntesis. El mensaje transcrito se enviará a FastAPI.
El backend extraerá una intención estructurada y ejecutará reglas deterministas de catálogo,
stock y carrito. Debe existir un adaptador opcional de OpenAI activado mediante USE_OPENAI,
pero la aplicación debe funcionar sin clave.

Usa arquitectura por capas: domain, repositories, services, api y static. No permitas que
la LLM modifique directamente datos. No expongas OPENAI_API_KEY. Incluye Dockerfile,
docker-compose.yml, .env.example, Makefile, README, documentación de arquitectura, API,
seguridad, plan de QA y roadmap. Incluye pruebas de health, catálogo, extracción de intención,
agregar al carrito, límite de stock e intención desconocida. Ejecuta Ruff y Pytest antes de
entregar. No dejes TODO críticos ni código simulado que impida ejecutar la demo.
```

## Criterios de aceptación para la LLM

- `uvicorn app.main:app` inicia sin errores.
- `/` muestra la interfaz.
- `/docs` muestra OpenAPI.
- El ejemplo de Cristal agrega dos cajas y totaliza CLP 49.980.
- `pytest` pasa.
- `ruff check .` pasa.
- No existen secretos en el repositorio.
- El proyecto incluye instrucciones reproducibles.
