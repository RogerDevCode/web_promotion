#!/usr/bin/env bash
set -euo pipefail
python -m ruff check .
python -m pytest --cov=app --cov-report=term-missing
python -m compileall -q app
printf '
QA COMPLETADO CORRECTAMENTE
'
