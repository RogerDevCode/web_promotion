# VoiceShop Pro

Starter kit profesional para demostrar ventas asistidas por voz en una botillería, florería, minimarket u otro retail.

## Qué demuestra

1. El cliente habla o escribe en lenguaje natural.
2. El sistema identifica acción, producto, presentación y cantidad.
3. El backend valida catálogo, precio y stock.
4. El carrito se actualiza en pantalla.
5. La respuesta se reproduce por voz.
6. El pedido puede quedar listo para intervención humana.

La versión predeterminada funciona sin clave API usando Web Speech API en el navegador y un parser determinista en Python. La integración opcional con OpenAI se activa con variables de entorno.

## Inicio rápido en Linux

```bash
unzip voiceshop-pro.zip
cd voiceshop-pro
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
uvicorn app.main:app --reload
```

Abrir `http://localhost:8000`.

## Activar OpenAI para extracción de intención

Editar `.env`:

```env
USE_OPENAI=true
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4.1-mini
```

La clave permanece únicamente en el servidor. Nunca debe agregarse a JavaScript ni publicarse en Git.

## QA

```bash
make qa
```

También puede ejecutarse:

```bash
pytest
ruff check .
```

## Documentación

- `docs/ARCHITECTURE.md`: componentes, flujo y evolución.
- `docs/API.md`: endpoints y contratos.
- `docs/LLM_REPLICATION_GUIDE.md`: instrucciones completas para que otra LLM replique el proyecto.
- `docs/QA_TEST_PLAN.md`: estrategia y casos de prueba.
- `docs/SECURITY.md`: controles mínimos antes de producción.
- `docs/PRODUCTION_ROADMAP.md`: migración desde demo a producto comercial.

## Limitaciones deliberadas

- Catálogo en JSON.
- Carrito en memoria y no persistente.
- Sin autenticación, pago ni despacho.
- La voz del navegador depende del sistema operativo y del navegador.
- La integración OpenAI incluida cubre extracción estructurada; Realtime/WebRTC se deja como evolución documentada.
